<?php

namespace Dww\Rewards\Api\Data;

interface RateInterface
{
    const ID = 'id';
    const CUSTOMER_ID = 'customer_id';
    const ORDER_ID = 'order_id';
    const DIRECTION = 'direction';
    const EARNED_POINTS = 'earned_point';
    const CREATED_TIME = 'created_time';
    const UPDATED_TIME = 'updated_time';

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Set ID
     *
     * @param $id
     * @return RateInterface
     */
    public function setId($id);


    /**
     * Get Customer_id
     *
     * @return int
     */
    public function getCustomer_id();


    /**
     * Set  Customer_id
     *
     * @param int $Customer_id
     * @return $this
     */
    public function setCustomer_id($customer_id);

    /**
     * Get order_id
     *
     * @return int
     */
    public function getOrder_id();


    /**
     * Set  order_id
     *
     * @param int $order_id
     * @return $this
     */
    public function setOrder_id($order_id);

    /**
     * Get earned_points
     *
     * @return int
     */
    public function getEarned_points();


    /**
     * Set  earned_points
     *
     * @param int $earned_points
     * @return $this
     */
    public function SetEarned_points($earned_points);

    /**
     * Get created_at
     *
     * @return timestamp
     */
    public function getCreated_at();


    /**
     * Set  created_at
     *
     * @param timestamp $created_at
     * @return $this
     */
    public function SetCreated_at($created_at);

    /**
     * Get updated_at
     *
     * @return timestamp
     */
    public function getUpdated_at();

    /**
     * Set  updated_at
     *
     * @param timestamp $updated_at
     * @return $this
     */
    public function SetUpdated_at($updated_at);
}