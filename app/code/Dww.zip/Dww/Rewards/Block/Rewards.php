<?php

namespace Dww\Rewards\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Dww\Rewards\Model\ResourceModel\Rewards\Collection;
use Dww\Rewards\Model\ResourceModel\Rewards\CollectionFactory;

class Rewards extends Template
{

    private $collectionFactory;
    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        array $data = array()
    ) {
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context, $data);
    }

    /**
     * @return \Dww\Rewards\Model\Rewards[]
     */
    public function getItems()
    {
        return $this->collectionFactory->create()->getItems();
    }
}
