<?php
namespace Dww\Rwards\Block;
class Totalrewards
{
protected $customer;
public function __construct(\Magento\Customer\Model\Session $customer)
{
    $this->customer = $customer;
}
public function yourMethodName()
{
    $customer = $this->customer;
    $customerName = $customer->getName();
    $customerId = $customer->getId();
//You will get all basic detail with this $customer object
}
}