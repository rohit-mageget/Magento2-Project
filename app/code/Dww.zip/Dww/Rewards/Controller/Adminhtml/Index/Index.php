<?php

namespace Dww\Rewards\Controller\Adminhtml\EarningRate;

use Dww\Rewards\Controller\Adminhtml\Rewards;

class Index extends Rewards
{
    /**
     * @return \Magento\Backend\Model\View\Result\Page $resultPage
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Dww_Rewards::earning_rate');
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('Earning Rates'));

        return $resultPage;
    }
}
