<?php
namespace Dww\Rewards\Controller\Cart;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Dww\Rewards\Model\RewardsFactory;

class Creditpost extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;
    protected $_helper;
    protected $_customerSession; 
    protected $customerRepository;
    protected $checkoutSession;
    protected $cart;
    protected $quoteRepository;
    protected $_quoteFactory;
    protected $resultJsonFactory;
    protected $_rewards;
    protected $total;


	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Dww\Rewards\Helper\Data $helper,
        \Magento\Customer\Model\Session $customerSession,
        CustomerRepositoryInterface $customerRepository,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
        \Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Quote\Model\Quote\Address\Total $total,
        \Magento\Framework\Controller\Result\RedirectFactory $resultRedirectFactory,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        RewardsFactory $rewards
                )
	{
		$this->_pageFactory = $pageFactory;
		$this->_helper = $helper;
        $this->_customerSession = $customerSession;
        $this->customerRepository = $customerRepository;
        $this->checkoutSession = $checkoutSession;
        $this->cart = $cart;
        $this->quoteRepository = $quoteRepository;
        $this->_quoteFactory = $quoteFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->total = $total;
        $this->resultRedirectFactory = $resultRedirectFactory;
        $this->messageManager = $messageManager;
        $this->_rewards = $rewards;
		return parent::__construct($context);
	}

	public function execute(){

        $gridData = $this->_rewards->create();

        $resultRedirect = $this->resultRedirectFactory->create();
        
        $quoteId = $this->checkoutSession->getQuote()->getId();
        $quoteData = $this->_quoteFactory->create()->load($quoteId);

        $preAddedDiscount = $quoteData->getStorecredit();

        $cartQuote = $this->cart->getQuote();

        $storeCredit = $this->getStoreCreditBalance();

        $formData = $this->getRequest()->getPost('totalrewards');
        $apply = $this->getRequest()->getPost('apply');
        $cancel = $this->getRequest()->getPost('cancel');

        // $order = $this->cart->getOrder()->getId();
        // $orderId=$order->getEntityId();
        // $incId = $order->getIncrementId();

        // print_r($order);
        // print_r($order);
        // die("rgdg");

            if(isset($storeCredit)){

                $grandTotal =$cartQuote->getSubtotal();
                if($apply == 'apply'){
        
                    $DiscountData = ($formData + $preAddedDiscount);
        
                    if($DiscountData <= $storeCredit && $DiscountData <= $grandTotal){
        
                        $quoteData->setData('totalrewards', $DiscountData);
                        $quoteData->save();
                        $storeprice = ($storeCredit - $formData);
            
                        $customerId = $this->_customerSession->getCustomer()->getId();
                        $customer = $this->customerRepository->getById($customerId);
                        $customer->setCustomAttribute('totalrewards', $storeprice);
                        $this->customerRepository->save($customer);
        
                        $order = $this->checkoutSession->getLastRealOrder();
                        $incId = "Used credit by user";
                       
                        $gridData->setCustomerId($customerId);
                        $gridData->setCreditChange(("-".$formData));
                        $gridData->setCurrentCredit($storeprice);
                        $gridData->setAction($incId);
                        $gridData->save();
            
                        $message = __('Total Price has been updated successfully'); 
                        $this->messageManager->addSuccessMessage($message);
                       
                        return $resultRedirect->setPath('checkout/cart');
            
            
                    }else{
            
                            $message = __('Please enter valid amount'); 
                            $this->messageManager->addErrorMessage($message);
                        return $resultRedirect->setPath('checkout/cart');
            
                    }
        
                }elseif($cancel == 'cancel'){
        
        
                    if($preAddedDiscount){
        
        
                        $storeprice = ($storeCredit + $preAddedDiscount);
                        $customerId = $this->_customerSession->getCustomer()->getId();
                        $customer = $this->customerRepository->getById($customerId);
                        $customer->setCustomAttribute('totalrewards', $storeprice);
                        $this->customerRepository->save($customer);
            
            
                        $preAddedDiscount = 0;
            
                        $quoteData->setData('totalrewards', $preAddedDiscount);
                        $quoteData->save();
                        $incId = "Cancel applyed credit by user";
                        $gridData->setCustomerId($customerId);
                        $gridData->setCreditChange(("-"));
                        $gridData->setAction($incId);
                        $gridData->setCurrentCredit($storeprice);
                        $gridData->save();
            
                        $message = __('Credit Price has been cleared successfully'); 
                        $this->messageManager->addSuccessMessage($message);
                       
                        return $resultRedirect->setPath('checkout/cart');
            
                    }else{
            
                            $message = __('There is no StoreCredit discount'); 
                            $this->messageManager->addErrorMessage($message);
                        return $resultRedirect->setPath('checkout/cart');
            
                    }
        
                }else{
        
                        $message = __('Error'); 
                        $this->messageManager->addErrorMessage($message);
                        return $resultRedirect->setPath('checkout/cart');
        
        
                }

            }else{

                $message = __('You have no credit amount'); 
                $this->messageManager->addErrorMessage($message);
                return $resultRedirect->setPath('checkout/cart');
            }
       

        return $this->_pageFactory->create();


    }
    public function getStoreCreditBalance()
    {
        $customerId = $this->_customerSession->getCustomer()->getId();
        $customer = $this->customerRepository->getById($customerId);

        if(null !== $customer->getCustomAttribute('totalrewards')){

        $attr = $customer->getCustomAttribute('totalrewards');
        $value = $attr->getValue();
        return $value;

        }
    }
}