<?php
declare(strict_types=1);
namespace Dww\Rewards\Controller\Customer;
use Magento\Framework\App\Action\Context;
use Dww\Rewards\Model\RewardsFactory;
class Index extends \Magento\Framework\App\Action\Action
{
 
    public function execute()
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        $order = '000000027';
        $orderId = $order->getIncrementId();
        $totalgrand =$order->getGrandTotal();

//         try {
//         switch($totalgrand){
//         case $totalgrand == 10 || $totalgrand < 50:
//         $rewardPoint = 5;
//         break;
//         case $totalgrand == 50 || $totalgrand < 100:
//         $rewardPoint = 10;
//         break;
//         case $totalgrand == 100 || $totalgrand < 500:
//         $rewardPoint = 15;
//         break;
//         default:
//         $rewardPoint = 0;
//         break;
//         }
//     } catch (\Throwable $th) {
//         echo "<pre>"; print_r($th->getMessage() );
//     }
// //   $logger->info('S');
// //   $logger->info(print_r($order->getData(), true));

//          $points=$rewardPoint;
//          $array = [
//             'customer_id' => $order->getCustomerId(),
//             'order_id' => $orderId,
//             'earned_points' => $points ,
//         ];

//             $rewardsfactory = $this->_rewards->create();
//     try {
//                if ($array) {
//                 $rewardsfactory->setData($array)->save();
//             }
//                     } catch (\Exception $e) {

//     }

    }

}