<?php

namespace Dww\Rewards\Controller\Customer;

class Totalrewards extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        // echo $this->_customerSession->getCustomer()->getId();
        $this->_view->loadLayout();
        $this->_view->renderLayout();
    }
}