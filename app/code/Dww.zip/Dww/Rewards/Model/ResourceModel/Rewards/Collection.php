<?php

namespace Dww\Rewards\Model\ResourceModel\Rewards;

use Dww\Rewards\Model\Rewards as RewardsModel;
use Dww\Rewards\Model\ResourceModel\Rewards as RewardsResourceModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'id';

    protected function _construct()
    {
        $this->_init(
            RewardsModel::class,
            RewardsResourceModel::class
        );
    }
}
