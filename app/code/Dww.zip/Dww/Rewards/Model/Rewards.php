<?php

namespace Dww\Rewards\Model;

use Dww\Rewards\Api\Data\RateInterface;

use Dww\Rewards\Model\ResourceModel\Rewards as RewardsResourceModel;

class Rewards extends \Magento\Framework\Model\AbstractModel  implements RateInterface
{
    const CACHE_TAG = 'dww_rewards';

    protected $_cacheTag = 'dww_rewards';
    protected $_eventPrefix = 'dww_rewards';

    protected function _construct()
    {
        $this->_init(RewardsResourceModel::class);
    }
    /**
     * Get ID
     *
     * @return int
     */
    public function getId()
    {
        return $this->getData(RateInterface::ID);
    }

    /**
     * Set  ID
     *
     * @param int $Id
     * @return $this
     */
    public function setId($id)
    {
        return $this->setData(RateInterface::ID, $id);
    }

    /**
     * Get Customer_id
     *
     * @return int
     */
    public function getCustomer_id()
    {
        return $this->getData(RateInterface::CUSTOMER_ID);
    }

    /**
     * Set  Customer_id
     *
     * @param int $Customer_id
     * @return $this
     */
    public function setCustomer_id($customer_id)
    {
        return $this->setData(RateInterface::CUSTOMER_ID, $customer_id);
    }
    /**
     * Get order_id
     *
     * @return int
     */
    public function getOrder_id()
    {
        return $this->getData(RateInterface::ORDER_ID);
    }

    /**
     * Set  order_id
     *
     * @param int $order_id
     * @return $this
     */
    public function setOrder_id($order_id)
    {
        return $this->setData(RateInterface::ORDER_ID, $order_id);
    }
    /**
     * Get earned_points
     *
     * @return int
     */
    public function getEarned_points()
    {
        return $this->getData(RateInterface::EARNED_POINTS);
    }

    /**
     * Set  earned_points
     *
     * @param int $earned_points
     * @return $this
     */
    public function SetEarned_points($earned_points)
    {
        return $this->setData(RateInterface::EARNED_POINTS, $earned_points);
    }
    /**
     * Get created_at
     *
     * @return timestamp
     */
    public function getCreated_at()
    {
        return $this->getData(RateInterface::CREATED_TIME);
    }

    /**
     * Set  created_at
     *
     * @param timestamp $created_at
     * @return $this
     */
    public function SetCreated_at($created_at)
    {
        return $this->setData(RateInterface::CREATED_TIME, $created_at);
    }
    /**
     * Get updated_at
     *
     * @return timestamp
     */
    public function getUpdated_at()
    {
        return $this->getData(RateInterface::UPDATED_TIME);
    }

    /**
     * Set  updated_at
     *
     * @param timestamp $updated_at
     * @return $this
     */
    public function SetUpdated_at($updated_at)
    {
        return $this->setData(RateInterface::UPDATED_TIME, $updated_at);
    }
}
