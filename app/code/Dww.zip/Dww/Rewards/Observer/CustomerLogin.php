<?php

namespace Dww\Rewards\Observer;

use Magento\Framework\Event\ObserverInterface;

class CustomerLogin implements ObserverInterface
{
    public function execute(\Magento\Framework\Event\Observer $observer)
    {

        $customer = $observer->getEvent()->getCustomer();
        print_r($customer->getTotalrewards()); //Get customer name
       // exit;
    }
}
