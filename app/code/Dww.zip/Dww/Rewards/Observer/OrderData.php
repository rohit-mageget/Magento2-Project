<?php
declare(strict_types=1);
namespace Dww\Rewards\Observer;
use Dww\Rewards\Model\RewardsFactory;
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
//use Dww\Rewards\Helper\Data;
class OrderData  implements ObserverInterface
{
     /**
     * @var Rewards
     */
    protected $_rewards;
    
    protected $resultPageFactory;

    public function __construct(
        RewardsFactory $rewards,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface

    ) {
        $this->_rewards = $rewards;
        $this->resultPageFactory = $resultPageFactory;
        $this->customerRepositoryInterface = $customerRepositoryInterface;
        $this->_customerFactory = $customerFactory;
    }
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
      
        $order = $observer->getEvent()->getOrder();
        $orderId = $order->getIncrementId();
        $totalgrand =$order->getGrandTotal();
        $customerId = $order->getCustomerId();
        $customer = $this->customerRepositoryInterface->getById($customerId);
        $customerAttributeData = $customer->__toArray();
        $isVendor = $customerAttributeData['custom_attributes']['totalrewards']['value'];
        
        try {
        switch($totalgrand){
        case $totalgrand == 10 || $totalgrand < 50:
        $rewardPoint = 5;
        break;
        case $totalgrand == 50 || $totalgrand < 100:
        $rewardPoint = 10;
        break;
        case $totalgrand == 100 || $totalgrand < 500:
        $rewardPoint = 15;
        break;
        default:
        $rewardPoint = 0;
        break;
        }
    } catch (\Throwable $th) {
        echo "<pre>"; print_r($th->getMessage() );
    }
  
    $updatetotalrewards=$isVendor + $rewardPoint ; 
    $customer = $this->_customerFactory->create()->load($customerId)->getDataModel();
    $customer->setCustomAttribute('totalrewards', $updatetotalrewards);
    $this->customerRepositoryInterface->save($customer);
 
         $points=$rewardPoint;
         $array = [
            'customer_id' => $order->getCustomerId(),
            'order_id' => $orderId,
            'earned_points' => $points ,
        ];

            $rewardsfactory = $this->_rewards->create();
    try {
               if ($array) {
                $rewardsfactory->setData($array)->save();
            }
                    } catch (\Exception $e) {

    }

    }

}