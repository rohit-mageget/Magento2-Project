<?php
namespace Dww\Rewards\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class SalesModelServiceQuoteSubmitSuccessObserver implements ObserverInterface
{

    /**
     * Fires when sales_order_place_after is dispatched
     *
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        //Order information
        $order = $observer->getEvent()->getOrder();
        //Quote information
        $quote = $observer->getEvent()->getQuote();

        //Get customer_id from order
        $customerId = $order->getCustomerId();

        //Or Get customer_id from quote
        $customerId = $quote->getCustomerId();
        // print_r($order);
        // exit;
    }
}
