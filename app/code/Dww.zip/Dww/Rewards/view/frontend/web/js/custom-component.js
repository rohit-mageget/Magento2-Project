define(['jquery',
         'uiComponent',
         'ko',
         'Magento_Customer/js/model/customer',
         'Magento_Checkout/js/model/quote',
         'Magento_Checkout/js/model/resource-url-manager',
        'Magento_Checkout/js/model/error-processor',
        'Magento_SalesRule/js/model/payment/discount-messages',
        'mage/storage',
        'mage/translate',
        'Magento_Checkout/js/action/get-payment-information',
        'Magento_Checkout/js/model/totals',
        'Magento_Checkout/js/model/full-screen-loader',
        'Magento_Checkout/js/action/recollect-shipping-rates'
], function ($, Component, ko, customer, quote, urlManager, errorProcessor, messageContainer, storage, $t, getPaymentInformationAction,
    totals, fullScreenLoader, recollectShippingRates) {
    'use strict';
    return Component.extend({
        defaults: {
            template: 'Dww_Rewards/knockout-test'
        },
        isCustomerLoggedIn: customer.isLoggedIn,
        initialize: function () {
            this._super();
        },
        getValue : function() {
            var para = $(".page-header .header.panel .header-forms span span#rewardsprice").html();
            var val = "Your TotalRewards :: " + para + ".00";
            return val;
     },
     getCss : function() {
        $("strong#block-discount-heading").css("color", "#006bb4");
},

getClick : function(){

$(".content form#discount-credit-form, strong#block-discount-heading").toggleClass('accordion');

},

        applyCredit: function () {
            fullScreenLoader.startLoader();
            var form = $("#discount-credit-form").get(0);
                var data = new FormData(form);
                data.append('apply', 'apply');
                var inputprice = $(".checkout-index-index form#discount-credit-form.accordion input#rewards").val();
                var rewardsvalue = $(".page-header .header.panel .header-forms #rewardsvalue").val();
                var totalrewardsvalue = (rewardsvalue - inputprice);
                // console.log(rewardsvalue);
                // console.log(inputprice);
                // alert("fdg");
                 $.ajax({
                      url: 'http://mage.magento.com/rewards/cart/couponpost',
                      type: "POST",
                      data: data,
                      processData: false,
                      contentType: false,
                      showLoader: true,
                      message: "Store Credit Added Successfully",
                      success: function (response) {
                        //   alert(response.message);
                                var message = "Store Credit Added Successfully";
                                var deferred;
                    
                                $(".page-header .header.panel .header-forms span span#rewardsprice").html(totalrewardsvalue);
                                ko.getValue();
                                    deferred = $.Deferred();
        
                                    totals.isLoading(true);
                                  
                                    recollectShippingRates();
                                    getPaymentInformationAction(deferred);
                                    $.when(deferred).done(function () {
                                        fullScreenLoader.stopLoader();
                                        totals.isLoading(false);
                                    });
                                    messageContainer.addSuccessMessage({
                                        'message': message
                                    });
                      },
                     error: function (response) {
                        //   alert(response.message);
                          fullScreenLoader.stopLoader();
                                totals.isLoading(false);
                                errorProcessor.process(response, messageContainer);
                     }
                  }); 
        }, 
        cancelCredit: function () {
            
            fullScreenLoader.startLoader();
            var form = $("#discount-credit-form").get(0);
                var data = new FormData(form);
                data.append('cancel', 'cancel');
                 $.ajax({
                      url: 'http://mage.magento.com/rewards/cart/couponpost',
                      type: "POST",
                      data: data,
                      processData: false,
                      contentType: false,
                      showLoader: true,
                      message: "Store Credit Clear Successfully",
                      success: function (response) {
                        //   alert(response.message);
                        //   fullScreenLoader.stopLoader();
                          var deferred;
        
                            deferred = $.Deferred();

                            totals.isLoading(true);
                            
                            recollectShippingRates();
                            getPaymentInformationAction(deferred);
                            $.when(deferred).done(function () {
                                fullScreenLoader.stopLoader();
                                totals.isLoading(false);
                            });
                            // messageContainer.addSuccessMessage({
                            //     'message': message
                            // });
                      },
                     error: function (response) {
                          alert(response.message);
                        //   fullScreenLoader.stopLoader();
                          fullScreenLoader.stopLoader();
                          totals.isLoading(false);
                        //   errorProcessor.process(response, messageContainer);
                     }
                  }); 
        }

    });
    
}
);