var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Magecomp_Extrafee/js/model/shipping-save-processor/default'
        }
    }
};
