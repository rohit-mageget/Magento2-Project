<?php
namespace Mageget\Checkout\Observer;
 
class SaveCustomFieldsInOrder implements \Magento\Framework\Event\ObserverInterface
{
    public function execute(\Magento\Framework\Event\Observer $observer) {
        $order = $observer->getEvent()->getOrder();
        $quote = $observer->getEvent()->getQuote();
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/logtest.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('Simple Text Log'); 
        $logger->info('Array Log'.print_r($quote, true));
        $order->setData('comment', $quote->getComment());
        $order->setData('image', $quote->getImage());
        $order->save($order);
        return $this;
    }
}