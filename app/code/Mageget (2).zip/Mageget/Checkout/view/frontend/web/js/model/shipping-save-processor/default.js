define(
    [
        'jquery',
        'ko',
        'Magento_Checkout/js/model/quote',
        'Magento_Checkout/js/model/resource-url-manager',
        'mage/storage',
        'Magento_Checkout/js/model/payment-service',
        'Magento_Checkout/js/model/payment/method-converter',
        'Magento_Checkout/js/model/error-processor',
        'Magento_Checkout/js/model/full-screen-loader',
        'Magento_Checkout/js/action/select-billing-address'
    ],
    function (
        $,
        ko,
        quote,
        resourceUrlManager,
        storage,
        paymentService,
        methodConverter,
        errorProcessor,
        fullScreenLoader,
        selectBillingAddressAction
    ) {
        'use strict';
 
        return {
            saveShippingInformation: function () {
                var payload;
 
                if (!quote.billingAddress()) {
                    selectBillingAddressAction(quote.shippingAddress());
                }

                // function preview_image(event){

                //     document.getElementById('output_image').style.display='block';
                //     var reader = new FileReader();
                //     reader.onload = function(){
                //         var output = document.getElementById('output_image');
                //         output.src = reader.result;
                //     }
                //     reader.readAsDataURL(event.target.files[0]);
                // }; 
 
                var comment = $('[name="custom_attributes[comment]"]').val();
                var image = $('input[name="custom_attributes[image]"]').val();
                // var reader = new FileReader();
                // var image = reader.image;
                // var image = reader.readAsDataURL(image.target.files[0]);
                // alert(image);
 
              
              
                // var filepath = document.getElementById('filepath').value;
                // document.getElementById('output_image').src=filepath;

                
                payload = {
                    addressInformation: {

                        shipping_address: quote.shippingAddress(),
                        billing_address: quote.billingAddress(),
                        shipping_method_code: quote.shippingMethod().method_code,
                        shipping_carrier_code: quote.shippingMethod().carrier_code,
                        extension_attributes:{
                            comment: comment,
                            image: image                
                        }
                    }
                };
                // payloadExtender(payload);
                fullScreenLoader.startLoader();
 
                return storage.post(
                    resourceUrlManager.getUrlForSetShippingInformation(quote),
                    JSON.stringify(payload)
                ).done(
                    function (response) {
                        quote.setTotals(response.totals);
                        paymentService.setPaymentMethods(methodConverter(response.payment_methods));
                        fullScreenLoader.stopLoader();
                    }
                ).fail(
                    function (response) {
                        errorProcessor.process(response);
                        fullScreenLoader.stopLoader();
                    }
                );
            }
        };
    }
);