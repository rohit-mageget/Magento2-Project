/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/* global Base64 */
define([
    'jquery',
    'underscore',
    'mageUtils',
    'Magento_Ui/js/modal/alert',
    'Magento_Ui/js/lib/validation/validator',
    'Magento_Ui/js/form/element/file-uploader',
    'mage/adminhtml/browser'
], function ($, _, utils, uiAlert, validator, Element, browser) {
    'use strict';

    return Element.extend({
        /**
         * {@inheritDoc}
         */
        initialize: function () {
            this._super();
          

            function preview_image(event){

                document.getElementById('output_image').style.display='block';
                var reader = new FileReader();
                reader.onload = function(){
                    var output = document.getElementById('output_image');
                    output.src = reader.result;
                }
                reader.readAsDataURL(event.target.files[0]);
            };


                jQuery("#eventform").on('click', function(){
                        var filepath = document.getElementById('filepath').value;
                         document.getElementById('output_image').src=filepath;
                    });
          
        },

     
    });
});
