<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2021 Mageget (https://www.Mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Api;

/**
 * @api
 */
interface FeedRepositoryInterface
{
    /**
     * Save
     *
     * @param \Mageget\Feed\Api\Data\FeedInterface $feed
     * @param bool $withReindex
     *
     * @return \Mageget\Feed\Api\Data\FeedInterface
     *
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function save(\Mageget\Feed\Api\Data\FeedInterface $feed, $withReindex = false);

    /**
     * Get by id
     *
     * @param int $feedId
     *
     * @return \Mageget\Feed\Api\Data\FeedInterface
     *
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($feedId);

    /**
     * Get model without data
     *
     * @return \Mageget\Feed\Api\Data\FeedInterface
     */
    public function getEmptyModel();

    /**
     * Delete
     *
     * @param \Mageget\Feed\Api\Data\FeedInterface $feed
     *
     * @return bool true on success
     *
     * @throws \Magento\Framework\Exception\CouldNotDeleteException
     */
    public function delete(\Mageget\Feed\Api\Data\FeedInterface $feed);

    /**
     * Delete by id
     *
     * @param int $feedId
     *
     * @return bool true on success
     *
     * @throws \Magento\Framework\Exception\CouldNotDeleteException
     */
    public function deleteById($feedId);

    /**
     * Lists
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     *
     * @return \Magento\Framework\Api\SearchResultsInterface
     *
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);
}
