<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2021 Mageget (https://www.Mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Api;

use Mageget\Feed\Api\Data\ScheduleInterface;

interface ScheduleRepositoryInterface
{
    /**
     * @param ScheduleInterface $scheduleModel
     * @return ScheduleInterface
     */
    public function save(ScheduleInterface $scheduleModel);

    /**
     * @param int $id
     * @return ScheduleInterface
     */
    public function get($id);

    /**
     * @param ScheduleInterface $scheduleModel
     * @return bool
     */
    public function delete(ScheduleInterface $scheduleModel);

    /**
     * @param int $id
     * @return bool
     */
    public function deleteById($id);

    /**
     * @param int $feedId
     * @return bool
     */
    public function deleteByFeedId($feedId);
}
