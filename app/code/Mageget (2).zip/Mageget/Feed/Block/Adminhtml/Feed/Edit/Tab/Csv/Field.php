<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2021 Mageget (https://www.amasty.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Block\Adminhtml\Feed\Edit\Tab\Csv;

/**
 * Class Field
 *
 * @package Mageget\Feed
 */
class Field extends \Mageget\Feed\Block\Adminhtml\Feed\Edit\Tab\Content
{
    protected $_template = 'feed/csv.phtml';
}
