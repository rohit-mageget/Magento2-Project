<?php
  
namespace Mageget\Feed\Block\Adminhtml\Feed\Edit\Tab;
  
use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Framework\Data\FormFactory;
use Magento\Cms\Model\Wysiwyg\Config;
// use Magebay\Hello\Model\System\Config\Status;
  
class Info extends Generic implements TabInterface
{
    /**
     * @var \Magento\Cms\Model\Wysiwyg\Config
     */
    protected $_wysiwygConfig;
  
    /**
     * @var \Magebay\Hello\Model\System\Config\Status
     */
    // protected $_status;
   /**
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param Config $wysiwygConfig
     * @param Status $status
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        Config $wysiwygConfig,
        // Status $status,
        array $data = []
    ) {
        $this->_wysiwygConfig = $wysiwygConfig;
        // $this->_status = $status;
        parent::__construct($context, $registry, $formFactory, $data);
    }
  
    /**
     * Prepare form fields
     *
     * @return \Magento\Backend\Block\Widget\Form
     */
    protected function _prepareForm()
    {
       /** @var $model \Magebay\Hello\Model\PostsFactory */
        $model = $this->_coreRegistry->registry('member_data');
  
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('members_');
        $form->setFieldNameSuffix('members');
  
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Address Information')]
        );
  
        if ($model->getId()) {
            $fieldset->addField(
                'address_id',
                'hidden',
                ['name' => 'address_id']
            );
        }
        $fieldset->addField(
            'title',
            'text',
            [
                'name'      => 'city',
                'label'     => __('City')
            ]
        );
        $data = $model->getData();
        $form->setValues($data);
        $this->setForm($form);
  
        return parent::_prepareForm();
    }
}