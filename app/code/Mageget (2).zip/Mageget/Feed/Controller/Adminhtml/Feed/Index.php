<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2021 Mageget (https://www.Mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Adminhtml\Feed;

use Magento\Framework\Controller\ResultFactory;

/**
 * Class Index
 *
 * @package Mageget\Feed
 */
class Index extends \Mageget\Feed\Controller\Adminhtml\AbstractFeed
{
    /**
     * @inheritdoc
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $resultPage->setActiveMenu('Mageget_Feed::feed_category');
        $resultPage->addBreadcrumb(__('Mageget Feed'), __('Mageget Feed'));
        $resultPage->addBreadcrumb(__('Feeds'), __('Feeds'));
        $resultPage->getConfig()->getTitle()->prepend(__('Feeds'));

        return $resultPage;
    }
}
