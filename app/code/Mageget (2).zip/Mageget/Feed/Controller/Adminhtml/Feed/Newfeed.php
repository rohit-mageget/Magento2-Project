<?php

namespace Mageget\Feed\Controller\Adminhtml\Feed;

class NewFeed extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    private $resultPageFactory;
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        // $resultPage->setActiveMenu("Mageget_StoreCredit::TransactionHistory");
        $resultPage
            ->getConfig()
            ->getTitle()
            ->prepend(__("New Feed"));
        return $resultPage;
    }
}
