<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2021 Mageget (https://www.amasty.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Category;

use Magento\Framework\Model\AbstractModel;

/**
 * Class Category Model
 *
 * @package Mageget\Feed
 */
class Category extends AbstractModel
{
    const FEED_CATEGORY_ID = 'feed_category_id';

    protected function _construct()
    {
        $this->_init(\Mageget\Feed\Model\Category\ResourceModel\Category::class);
        $this->setIdFieldName(self::FEED_CATEGORY_ID);
    }
}
