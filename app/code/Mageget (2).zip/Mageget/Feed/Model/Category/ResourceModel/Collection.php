<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2021 Mageget (https://www.amasty.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Category\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Category Collection
 *
 * @package Mageget\Feed
 */
class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(
            \Mageget\Feed\Model\Category\Category::class,
            \Mageget\Feed\Model\Category\ResourceModel\Category::class
        );
    }

    /**
     * Add google setup filter
     *
     * @return $this
     */
    public function addGoogleSetupFilter()
    {
        $this->addFieldToFilter(
            'code',
            ['like' => "google_category_%"]
        );

        return $this;
    }
}
