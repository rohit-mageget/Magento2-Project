<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2021 Mageget (https://www.Mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\ResourceModel\Feed;

/**
 * Class Feed Collection
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected function _construct()
    {
        parent::_construct();
        $this->_init(\Mageget\Feed\Model\Feed::class, \Mageget\Feed\Model\ResourceModel\Feed::class);
        $this->_setIdFieldName($this->getResource()->getIdFieldName());
    }
}
