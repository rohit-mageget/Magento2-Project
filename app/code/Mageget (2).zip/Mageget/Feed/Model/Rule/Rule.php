<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2021 Mageget (https://www.amasty.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Rule;

/**
 * Class Rule
 */
class Rule extends \Magento\CatalogRule\Model\Rule
{

}
