<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */

namespace Mageget\ProductFeed\Block\Adminhtml;

/**
 * Class Feed
 *
 * @package Mageget\ProductFeed
 */
class Feed extends \Magento\Backend\Block\Widget\Grid\Container
{
    protected function _construct()
    {
        $this->_controller = 'adminhtml';
        $this->_blockGroup = 'Mageget_ProductFeed';
        $this->_headerText = __('Feeds');
        $this->_addButtonLabel = __('Add New Feed');
        parent::_construct();
    }
}
