<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\ProductFeed\Block\Adminhtml\Feed\Edit\Tab\Csv;

/**
 * Class Field
 *
 * @package Mageget\ProductFeed
 */
class Field extends \Mageget\ProductFeed\Block\Adminhtml\Feed\Edit\Tab\Content
{
    protected $_template = 'feed/csv.phtml';
}
