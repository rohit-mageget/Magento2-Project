<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Block\Adminhtml;

/**
 * Class GoogleWizard
 *
 * @package Mageget\Feed
 */
class GoogleWizard extends \Magento\Backend\Block\Widget\Grid\Container
{
    protected function _construct()
    {
        $this->_controller = 'adminhtml';
        $this->_blockGroup = 'Mageget_Feed';
        $this->_headerText = __('GoogleWizard');
        $this->_addButtonLabel = __('Setup Google Wizard');
        parent::_construct();
    }
}
