<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\ProductFeed\Controller\Adminhtml;

/**
 * Class AbstractFeed
 *
 * @package Mageget\ProductFeed
 */
abstract class AbstractFeed extends \Magento\Backend\App\Action
{
    /**
     * Authorization level of a basic admin action
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'Mageget_ProductFeed::feed';
}
