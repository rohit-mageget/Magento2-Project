<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Adminhtml\Category;

use Mageget\Feed\Controller\Adminhtml\AbstractCategory;
use Mageget\Feed\Model\Category\Repository;
use Magento\Backend\App\Action;
use Psr\Log\LoggerInterface;

/**
 * Class Delete
 *
 * @package Mageget\Feed
 */
class Delete extends AbstractCategory
{
    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var Repository
     */
    private $repository;

    public function __construct(
        Repository $repository,
        LoggerInterface $logger,
        Action\Context $context
    ) {
        parent::__construct($context);
        $this->logger = $logger;
        $this->repository = $repository;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        if ($categoryId = $this->getRequest()->getParam('id')) {
            try {
                $this->repository->deleteById($categoryId);
                $this->messageManager->addSuccessMessage(__('You deleted the category.'));

                return $this->_redirect('mgfeed/*/');
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage(
                    __('We can\'t delete the category right now. Please review the log and try again.')
                );
                $this->logger->critical($e);

                return $this->_redirect('mgfeed/*/edit', ['id' => $this->getRequest()->getParam('id')]);
            }
        }

        $this->messageManager->addErrorMessage(__('We can\'t find a category to delete.'));
        return $this->_redirect('mgfeed/*/');
    }
}
