<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Adminhtml\Category;

use Mageget\Feed\Controller\Adminhtml\AbstractCategory;
use Mageget\Feed\Model\Category\CategoryFactory;
use Mageget\Feed\Model\Category\Repository;
use Magento\Backend\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Registry;

/**
 * Class Edit
 *
 * @package Mageget\Feed
 */
class Edit extends AbstractCategory
{
    /**
     * @var Registry
     */
    private $registry;

    /**
     * @var Repository
     */
    private $repository;

    /**
     * @var CategoryFactory
     */
    private $categoryFactory;

    public function __construct(
        Action\Context $context,
        Registry $registry,
        Repository $repository,
        CategoryFactory $categoryFactory
    ) {
        parent::__construct($context);
        $this->registry = $registry;
        $this->repository = $repository;
        $this->categoryFactory = $categoryFactory;
    }

    public function execute()
    {
        $model = $this->categoryFactory->create();
        if ($categoryId = $this->getRequest()->getParam('feed_category_id')) {
            try {
                $model = $this->repository->getById($categoryId);
            } catch (NoSuchEntityException $exception) {
                $this->messageManager->addErrorMessage(__('This category no longer exists.'));

                return $this->_redirect('mgfeed/*');
            } catch (\Exception $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());

                return $this->_redirect('mgfeed/*');
            }
        }

        // set entered data if was error when we do save
        $data = $this->_session->getPageData(true);
        if (!empty($data)) {
            $model->addData($data);
        }

        $this->registry->register('current_mgfeed_category', $model);

        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $resultPage->setActiveMenu('Mageget_Feed::feed_category');
        $resultPage->addBreadcrumb(__('Mageget Feed'), __('Mageget Feed'));
        $resultPage->addBreadcrumb(__('Categories Mapping Edit'), __('Categories Mapping Edit'));
        $resultPage->getConfig()->getTitle()->prepend(
            $model->getFeedCategoryId() ? $model->getName() : __('New Categories Mapping')
        );

        return $resultPage;
    }
}
