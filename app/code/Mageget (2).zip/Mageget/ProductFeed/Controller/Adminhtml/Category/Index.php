<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Adminhtml\Category;

use Mageget\Feed\Controller\Adminhtml\AbstractCategory;
use Magento\Framework\Controller\ResultFactory;

/**
 * Class Index
 *
 * @package Mageget\Feed
 */
class Index extends AbstractCategory
{
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $resultPage->setActiveMenu('Mageget_Feed::feed_category');
        $resultPage->addBreadcrumb(__('Mageget Feed'), __('Mageget Feed'));
        $resultPage->addBreadcrumb(__('Categories Mapping'), __('Categories Mapping'));
        $resultPage->getConfig()->getTitle()->prepend(__('Categories Mapping'));

        return $resultPage;
    }
}
