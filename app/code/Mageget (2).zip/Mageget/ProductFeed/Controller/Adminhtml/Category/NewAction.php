<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Adminhtml\Category;

use Mageget\Feed\Controller\Adminhtml\AbstractCategory;

/**
 * Class NewAction
 *
 * @package Mageget\Feed
 */
class NewAction extends AbstractCategory
{
    public function execute()
    {
        $this->_forward('edit');
    }
}
