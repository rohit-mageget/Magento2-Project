<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Adminhtml\Feed;

/**
 * Class Duplicate
 *
 * @package Mageget\Feed
 */
class Duplicate extends AbstractMassAction
{
    /**
     * {@inheritdoc}
     */
    public function massAction($collection)
    {
        foreach ($collection as $model) {
            $this->feedCopier->copy($model);
            $this->messageManager->addSuccessMessage(__('Feed %1 was duplicated', $model->getName()));
        }
    }
}
