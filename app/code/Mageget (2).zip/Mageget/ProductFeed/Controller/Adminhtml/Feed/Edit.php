<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\ProductFeed\Controller\Adminhtml\Feed;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Exception\NoSuchEntityException;
use Mageget\ProductFeed\Model\FeedFactory;

/**
 * Class Edit
 *
 * @package Mageget\ProductFeed
 */
class Edit extends \Mageget\ProductFeed\Controller\Adminhtml\AbstractFeed
{

    /**
     * @var \Magento\Framework\Registry
     */
    private $registry;
    private $feedfactory;

    /**
     * @var \Mageget\Feed\Model\Rule\RuleFactory
     */
    private $ruleFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $registry,
        \Mageget\Feed\Model\Rule\RuleFactory $ruleFactory,
        FeedFactory $feedfactory
    ) {
        parent::__construct($context);
        $this->registry = $registry;
        $this->ruleFactory = $ruleFactory;
        $this->feedfactory = $feedfactory;
    }

    public function execute()
    {
        $feedmodel = $this->feedfactory->create();

        if ($feedId = $this->getRequest()->getParam('id')) {
            try {
                $model = $feedmodel->load($feedId);
            } catch (NoSuchEntityException $exception) {
                $this->messageManager->addErrorMessage(__('This feed no longer exists.'));

                return $this->_redirect('mgfeed/*');
            }
        } else {
            $model = $feedmodel->load(0);
        }
        $rule = $this->ruleFactory->create();

        $rule->setConditions([])
            ->setConditionsSerialized($model->getConditionsSerialized())
            ->getConditions()
            ->setJsFormObject('rule_conditions_fieldset');

        $this->registry->register('current_mgfeed_feed', $model);
        $this->registry->register('current_mgfeed_rule', $rule);
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $resultPage->setActiveMenu('Mageget_ProductFeed::feed');
        $resultPage->addBreadcrumb(__('Mageget Feed'), __('Mageget Feed'));
        $resultPage->addBreadcrumb(__('Feed Edit'), __('Feed Edit'));
        $resultPage->getConfig()->getTitle()->prepend(
            $model->getEntityId() ? $model->getName() : __('New Feed')
        );

        return $resultPage;
    }
}
