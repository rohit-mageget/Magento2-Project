<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Adminhtml\Feed;

use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class FromTemplate
 *
 * @package Mageget\Feed
 */
class FromTemplate extends \Mageget\Feed\Controller\Adminhtml\AbstractFeed
{
    /**
     * @var \Mageget\Feed\Model\Feed\Copier
     */
    private $feedCopier;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;

    /**
     * @var \Mageget\Feed\Api\FeedRepositoryInterface
     */
    private $repository;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Psr\Log\LoggerInterface $logger,
        \Mageget\Feed\Model\Feed\Copier $feedCopier,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Mageget\Feed\Api\FeedRepositoryInterface $repository
    ) {
        parent::__construct($context);
        $this->logger = $logger;
        $this->feedCopier = $feedCopier;
        $this->storeManager = $storeManager;
        $this->repository = $repository;
    }

    public function execute()
    {
        if ($feedId = $this->getRequest()->getParam('id')) {
            try {
                $model = $this->repository->getById($feedId);
            } catch (NoSuchEntityException $exception) {
                $this->messageManager->addErrorMessage(__('This feed no longer exists.'));

                return $this->_redirect('mgfeed/*');
            }

            try {
                $storeId = $this->storeManager->getStore()->getId();
                /** @var \Mageget\Feed\Model\Feed $newModel */
                $newModel = $this->feedCopier->fromTemplate($model, $storeId);

                $this->messageManager->addSuccessMessage(__('Feed %1 created', $newModel->getName()));

                return $this->_redirect('mgfeed/*/edit', ['id' => $newModel->getId()]);
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage(
                    __('Something went wrong while export feed data. Please review the error log.')
                );

                $this->logger->critical($e);
            }
        }

        return $this->_redirect('mgfeed/*');
    }
}
