<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\ProductFeed\Controller\Adminhtml\Feed;

use Magento\Framework\Controller\ResultFactory;

/**
 * Class Index
 *
 * @package Mageget\ProductFeed
 */
class Index extends \Mageget\ProductFeed\Controller\Adminhtml\AbstractFeed
{
    /**
     * @inheritdoc
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $resultPage->setActiveMenu('Mageget_ProductFeed::feed_category');
        $resultPage->addBreadcrumb(__('Mageget ProductFeed'), __('Mageget ProductFeed'));
        $resultPage->addBreadcrumb(__('Feeds'), __('Feeds'));
        $resultPage->getConfig()->getTitle()->prepend(__('Feeds'));

        return $resultPage;
    }
}
