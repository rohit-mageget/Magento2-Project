<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Adminhtml\Feed;

use Mageget\Feed\Controller\Adminhtml\AbstractFeed;

/**
 * Class NewAction
 *
 * @package Mageget\Feed
 */
class NewAction extends AbstractFeed
{
    /**
     * @inheritdoc
     */
    public function execute()
    {
        $this->_forward('edit');
    }
}
