<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\ProductFeed\Controller\Adminhtml\Feed;

use Mageget\ProductFeed\Api\Data\FeedInterface;
use Mageget\ProductFeed\Controller\Adminhtml\AbstractFeed;
use Mageget\ProductFeed\Model\Rule\Rule;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class Save
 *
 * @package Mageget\ProductFeed
 */
class Save extends AbstractFeed
{
    /**
     * @var \Mageget\ProductFeed\Model\Rule\RuleFactory
     */
    private $ruleFactory;

    /**
     * @var \Mageget\ProductFeed\Model\FeedFactory
     */
    private $feedFactory;

    /**
     * @var \Magento\Framework\Encryption\EncryptorInterface
     */
    private $encryptor;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Psr\Log\LoggerInterface $logger,
        \Mageget\ProductFeed\Model\Rule\RuleFactory $ruleFactory,
        \Mageget\ProductFeed\Model\FeedFactory $feedFactory,
        \Magento\Framework\Encryption\EncryptorInterface $encryptor
    ) {
        parent::__construct($context);

        $this->ruleFactory = $ruleFactory;
        $this->feedFactory = $feedFactory;
        $this->encryptor = $encryptor;
        $this->logger = $logger;
    }

    public function execute()
    {
        try {
            $data = $this->getRequest()->getPostValue();
            $model = $this->feedFactory->create();

            $model = $model->setData($data)->save();
            $this->messageManager->addSuccessMessage(__('You saved the feed.'));

            if ($this->getRequest()->getParam('back')) {
                return $this->_redirect('mgpfeed/feed/edit', ['id' => $model->getId()]);
            }

            return $this->_redirect('mgpfeed/*/');
        } catch (LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
            $id = (int)$this->getRequest()->getParam('feed_entity_id');

            if (!empty($id)) {
                return $this->_redirect('mgpfeed/*/edit', ['id' => $id]);
            } else {
                return $this->_redirect('mgpfeed/*/new');
            }
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(
                __('Something went wrong while saving the feed data. Please review the error log.')
            );
            $this->logger->critical($e);
            $this->_session->setPageData($data);
            return $this->_redirect('mgpfeed/*/edit', ['id' => $this->getRequest()->getParam('feed_entity_id')]);
        }
    }
}
