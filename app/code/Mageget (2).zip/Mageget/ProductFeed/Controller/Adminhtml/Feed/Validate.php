<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Adminhtml\Feed;

/**
 * empty Class Validate
 * for back compatibility
 * @package Mageget\Feed
 */
class Validate
{

}
