<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Adminhtml\Field;

use Mageget\Feed\Controller\Adminhtml\AbstractField;
use Magento\Framework\Controller\ResultFactory;

class Index extends AbstractField
{
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $resultPage->setActiveMenu('Mageget_Feed::feed_field');
        $resultPage->addBreadcrumb(__('Mageget Feed'), __('Mageget Feed'));
        $resultPage->addBreadcrumb(__('Condition-Based Attributes'), __('Condition-Based Attributes'));
        $resultPage->getConfig()->getTitle()->prepend(__('Condition-Based Attributes'));

        return $resultPage;
    }
}
