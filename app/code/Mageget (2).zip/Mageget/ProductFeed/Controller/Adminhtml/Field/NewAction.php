<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Adminhtml\Field;

use Mageget\Feed\Controller\Adminhtml\AbstractField;

/**
 * Class NewAction
 *
 * @package Mageget\Feed
 */
class NewAction extends AbstractField
{
    public function execute()
    {
        $this->_forward('edit');
    }
}
