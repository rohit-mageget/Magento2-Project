<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Adminhtml\GoogleWizard;

use Mageget\Feed\Controller\Adminhtml\AbstractGoogleWizard;
use Mageget\Feed\Model\RegistryContainer;
use Magento\Framework\Controller\ResultFactory;

/**
 * Class Index
 *
 * @package Mageget\Feed
 */
class Index extends AbstractGoogleWizard
{
    /**
     * @var RegistryContainer
     */
    private $registryContainer;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Mageget\Feed\Model\RegistryContainer $registryContainer
    ) {
        parent::__construct($context);
        $this->registryContainer = $registryContainer;
    }

    /**
     * @inheritdoc
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);

        $valueOfFirstStep = RegistryContainer::VALUE_FIRST_STEP;
        $step = $this->getRequest()->getParam(RegistryContainer::VAR_STEP, $valueOfFirstStep);
        $categoryMappedId = $this->getRequest()->getParam(RegistryContainer::VAR_CATEGORY_MAPPER);
        $identifierExistsId = $this->getRequest()->getParam(RegistryContainer::VAR_IDENTIFIER_EXISTS);
        $feedId = $this->getRequest()->getParam(RegistryContainer::VAR_FEED);

        $this->registryContainer->setValue(RegistryContainer::VAR_CATEGORY_MAPPER, $categoryMappedId);
        $this->registryContainer->setValue(RegistryContainer::VAR_FEED, $feedId);
        $this->registryContainer->setValue(RegistryContainer::VAR_IDENTIFIER_EXISTS, $identifierExistsId);
        $this->registryContainer->setValue(RegistryContainer::VAR_STEP, $step);

        $resultPage->setActiveMenu('Mageget_Feed::feed');
        $resultPage->addBreadcrumb(__('Mageget Feed'), __('Mageget Feed'));
        $resultPage->addBreadcrumb(__('Google Feed Wizard'), __('Google Feed Wizard'));
        $resultPage->getConfig()->getTitle()->prepend(__('Google Feed Wizard'));

        return $resultPage;
    }
}
