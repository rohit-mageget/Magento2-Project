<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Controller\Feed;

/**
 * Class Download
 *
 * @package Mageget\Feed
 */
class Download extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Mageget\Feed\Model\Feed\Downloader
     */
    private $feedDownloader;

    /**
     * @var \Mageget\Feed\Model\FeedRepository
     */
    private $feedRepository;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Mageget\Feed\Model\FeedRepository $feedRepository,
        \Mageget\Feed\Model\Feed\Downloader $feedDownloader
    ) {
        $this->feedDownloader = $feedDownloader;
        $this->feedRepository = $feedRepository;

        parent::__construct($context);
    }

    /**
     * @inheritdoc
     */
    public function execute()
    {
        $feedId = $this->getRequest()->getParam('id');
        $fileName = $this->getRequest()->getParam('file');

        try {
            $feedModel = $this->feedRepository->getById($feedId);
        } catch (\Exception $exception) {
            return $this->_redirect($this->_redirect->getRefererUrl());
        }

        if ($fileName) {
            $this->feedDownloader->setFilename($fileName);
        }

        if ($feedModel->getIsTemplate() != 1) {
            return $this->feedDownloader->getResponse($feedModel);
        }

        return $this->_redirect($this->_redirect->getRefererUrl());
    }
}
