<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Category;

use Magento\Framework\Model\AbstractModel;

/**
 * Class Mapping Model
 *
 * @package Mageget\Feed
 */
class Mapping extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(\Mageget\Feed\Model\Category\ResourceModel\Mapping::class);
        $this->setIdFieldName('entity_id');
    }
}
