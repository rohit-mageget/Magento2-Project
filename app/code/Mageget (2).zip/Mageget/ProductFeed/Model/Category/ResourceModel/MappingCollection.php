<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Category\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Catalog Category MappingCollection
 *
 * @package Mageget\Feed
 */
class MappingCollection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(
            \Mageget\Feed\Model\Category\Mapping::class,
            \Mageget\Feed\Model\Category\ResourceModel\Mapping::class
        );
    }
}
