<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Category;

use Mageget\Feed\Model\Category\ResourceModel\Taxonomy as ResourceTaxonomy;

/**
 * Class Taxonomy
 *
 * @package Mageget\Feed
 */
class Taxonomy extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this->_init(ResourceTaxonomy::class);
    }
}
