<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Export\Adapter;

use Magento\Framework\Exception\LocalizedException;

/**
 * Class AdapterProvider
 */
class AdapterProvider
{
    private $adapters;

    public function __construct($adapters)
    {
        $this->adapters = $adapters;
    }

    public function get($adapterName, $params)
    {
        if (!isset($this->adapters[$adapterName])) {
            throw new LocalizedException(__('Please correct the file format.'));
        }

        return $this->adapters[$adapterName]->create($params);
    }
}
