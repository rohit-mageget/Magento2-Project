<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Field;

/**
 * Class Field
 *
 * @package Mageget\Feed
 */
class Field extends \Magento\Framework\Model\AbstractModel
{
    const FEED_FIELD_ID = 'feed_field_id';

    protected function _construct()
    {
        $this->_init(ResourceModel\Field::class);
        $this->setIdFieldName(self::FEED_FIELD_ID);
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->getData('name');
    }

    /**
     * @return string
     */
    public function getCode()
    {
        return $this->getData('code');
    }
}
