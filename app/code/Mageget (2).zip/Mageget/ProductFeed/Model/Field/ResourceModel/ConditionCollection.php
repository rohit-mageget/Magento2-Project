<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Field\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class ConditionCollection
 *
 * @package Mageget\Feed
 */
class ConditionCollection extends AbstractCollection
{
    protected function _construct()
    {
        parent::_construct();

        $this->_init(
            \Mageget\Feed\Model\Field\Condition::class,
            \Mageget\Feed\Model\Field\ResourceModel\Condition::class
        );
        $this->_setIdFieldName($this->getResource()->getIdFieldName());
    }
}
