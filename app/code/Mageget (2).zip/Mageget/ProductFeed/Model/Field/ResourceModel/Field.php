<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Field\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\VersionControl\AbstractDb;

/**
 * Class Field Resource Model
 *
 * @package Mageget\Feed
 */
class Field extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('mageget_feed_field', 'feed_field_id');
    }
}
