<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\GoogleWizard;

use Mageget\Feed\Model\Export\Product as ExportProduct;

/**
 * Class Color
 */
class Color extends Element
{
    protected $type = 'attribute';

    protected $tag = 'g:color';

    protected $modify = 'html_escape';

    protected $name = 'color';

    protected $description = 'Color of the item';

    protected $limit = 100;
}
