<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\GoogleWizard;

use Mageget\Feed\Model\Export\Product as ExportProduct;

/**
 * Class Description
 */
class Description extends Element
{
    protected $type = 'attribute';

    protected $tag = 'description';

    protected $limit = 500;

    protected $modify = 'html_escape';

    protected $value = ExportProduct::PREFIX_PRODUCT_ATTRIBUTE . '|description';

    protected $required = true;

    protected $name = 'description';

    protected $description = 'Description of the item';

    public function getModify()
    {
        $modify = $this->modify;
        if ($this->limit) {
            $modify .= '|length:' . $this->limit;
        }

        return $modify;
    }
}
