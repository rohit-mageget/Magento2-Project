<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\GoogleWizard;

/**
 * Class Mpn
 */
class Mpn extends Element
{
    protected $type = 'attribute';

    protected $tag = 'g:mpn';

    protected $modify = 'html_escape';

    protected $name = 'mpn';

    protected $description = 'Manufacturer Part Number (MPN) of the item';

    protected $limit = 70;
}
