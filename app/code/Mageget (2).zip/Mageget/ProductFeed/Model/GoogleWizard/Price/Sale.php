<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\GoogleWizard\Price;

use Mageget\Feed\Model\Export\Product as ExportProduct;

/**
 * Class Sale
 */
class Sale extends \Mageget\Feed\Model\GoogleWizard\Element
{
    protected $type = 'attribute';

    protected $tag = 'g:sale_price';

    protected $format = 'price';

    protected $value = ExportProduct::PREFIX_PRODUCT_ATTRIBUTE . '|special_price';

    protected $name = 'sale price';

    protected $description = 'Advertised sale price of the item';
}
