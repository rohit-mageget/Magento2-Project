<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\GoogleWizard;

/**
 * Class Size
 */
class Size extends Element
{
    protected $type = 'attribute';

    protected $tag = 'g:size';

    protected $modify = 'html_escape';

    protected $name = 'size';

    protected $description = 'Size of the item';

    protected $limit = 100;
}
