<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\GoogleWizard;

use Mageget\Feed\Model\Export\Product as ExportProduct;

/**
 * Class Title
 */
class Title extends Element
{
    protected $type = 'attribute';

    protected $tag = 'title';

    protected $limit = 150;

    protected $modify = 'html_escape';

    protected $value = ExportProduct::PREFIX_PRODUCT_ATTRIBUTE . '|name';

    protected $required = true;

    protected $name = 'title';

    protected $description = 'Title of the item';

    public function getModify()
    {
        $modify = $this->modify;
        if ($this->limit) {
            $modify .= '|length:' . $this->limit;
        }

        return $modify;
    }
}
