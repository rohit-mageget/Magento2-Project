<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\GoogleWizard;

use Mageget\Feed\Model\Export\Product as ExportProduct;

/**
 * Class Type
 */
class Type extends Element
{
    protected $type = 'attribute';

    protected $tag = 'g:product_type';

    protected $modify = 'html_escape';

    protected $value = ExportProduct::PREFIX_CATEGORY_ATTRIBUTE . '|category';

    protected $name = 'product type';

    protected $description = 'Your category of the item';
}
