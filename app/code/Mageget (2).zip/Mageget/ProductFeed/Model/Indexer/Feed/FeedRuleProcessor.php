<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Indexer\Feed;

use Magento\Framework\Indexer\AbstractProcessor;

class FeedRuleProcessor extends AbstractProcessor
{
    const INDEXER_ID = 'mageget_feed_entity';
}
