<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Indexer\Product;

use Magento\Framework\Indexer\AbstractProcessor;

class ProductFeedProcessor extends AbstractProcessor
{
    const INDEXER_ID = 'mageget_feed_product';
}
