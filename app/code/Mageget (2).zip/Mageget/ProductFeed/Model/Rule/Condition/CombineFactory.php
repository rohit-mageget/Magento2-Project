<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Rule\Condition;

/**
 * Class CombineFactory
 */
class CombineFactory extends \Magento\CatalogRule\Model\Rule\Condition\CombineFactory
{
}
