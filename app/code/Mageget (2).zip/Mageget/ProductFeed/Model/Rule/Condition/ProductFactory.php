<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\Rule\Condition;

/**
 * Class ProductFactory
 */
class ProductFactory extends \Magento\CatalogRule\Model\Rule\Condition\ProductFactory
{
}
