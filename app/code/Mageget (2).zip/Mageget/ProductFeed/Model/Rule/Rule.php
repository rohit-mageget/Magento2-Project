<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\ProductFeed\Model\Rule;

/**
 * Class Rule
 */
class Rule extends \Magento\CatalogRule\Model\Rule
{

}
