<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Model\ValidProduct\ResourceModel;

use Mageget\Feed\Api\Data\ValidProductsInterface;
use Magento\Framework\Model\ResourceModel\Db\VersionControl\AbstractDb;

/**
 * Class ValidProduct
 *
 * @package Mageget\Feed
 */
class ValidProduct extends AbstractDb
{
    const TABLE_NAME = 'mageget_feed_valid_products';

    /**
     * {@inheritdoc}
     */
    protected function _construct()
    {
        $this->_init(self::TABLE_NAME, ValidProductsInterface::ENTITY_ID);
    }
}
