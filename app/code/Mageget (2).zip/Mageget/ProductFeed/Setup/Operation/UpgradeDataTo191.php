<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Setup\Operation;

/**
 * Class UpgradeDataTo191
 */
class UpgradeDataTo191
{
    const NOT_SUPPORTED = ['hourly', 'daily', 'weekly', 'monthly'];

    /**
     * @var \Mageget\Feed\Model\ResourceModel\Feed\CollectionFactory
     */
    private $feedCollectionFactory;

    /**
     * @var \Mageget\Feed\Model\ResourceModel\Feed
     */
    private $resourceModelFeed;

    /**
     * @var \Mageget\Feed\Model\Import
     */
    private $import;

    public function __construct(
        \Mageget\Feed\Model\ResourceModel\Feed\CollectionFactory $feedCollectionFactory,
        \Mageget\Feed\Model\ResourceModel\Feed $resourceModelFeed,
        \Mageget\Feed\Model\Import $import
    ) {
        $this->feedCollectionFactory = $feedCollectionFactory;
        $this->resourceModelFeed = $resourceModelFeed;
        $this->import = $import;
    }

    public function execute()
    {
        $this->import->update('google');

        /** @var \Mageget\Feed\Model\ResourceModel\Feed\Collection $feedCollection */
        $feedCollection = $this->feedCollectionFactory->create();
        $feeds = $feedCollection->addFieldToFilter('execute_mode', ['in' => self::NOT_SUPPORTED])->getItems();

        /** @var \Mageget\Feed\Model\Feed $feed */
        foreach ($feeds as $feed) {
            switch ($feed->getExecuteMode()) {
                case 'hourly':
                case 'daily':
                    $feed->setCronDay(\Mageget\Feed\Model\CronProvider::EVERY_DAY);
                    $feed->setCronTime(0);
                    break;

                case 'weekly':
                case 'monthly':
                    $feed->setCronDay('1');
                    $feed->setCronTime(0);
                    break;
            }

            $feed->setExecuteMode('schedule');
            $this->resourceModelFeed->save($feed);
        }
    }
}
