<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Setup\Operation;

/**
 * Class UpgradeTo101
 */
class UpgradeTo101
{
    /**
     * @var \Magento\Framework\Setup\SampleData\Executor
     */
    private $executor;

    /**
     * @var \Mageget\Feed\Setup\Updater
     */
    private $updater;

    public function __construct(
        \Magento\Framework\Setup\SampleData\Executor $executor,
        \Mageget\Feed\Setup\Updater $updater
    ) {
        $this->executor = $executor;
        $this->updater = $updater;
    }

    public function execute()
    {
        $this->updater->setTemplates(['bing']);
        $this->executor->exec($this->updater);
    }
}
