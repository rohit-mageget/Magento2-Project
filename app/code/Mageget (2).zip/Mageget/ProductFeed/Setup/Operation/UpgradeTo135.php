<?php
/**
 * @author Mageget Team
 * @copyright Copyright (c) 2020 Mageget (https://www.mageget.com)
 * @package Mageget_Feed
 */


namespace Mageget\Feed\Setup\Operation;

/**
 * Class UpgradeTo135
 */
class UpgradeTo135
{
    /**
     * @var \Mageget\Feed\Setup\SerializedFieldDataConverter
     */
    private $fieldDataConverter;

    public function __construct(\Mageget\Feed\Setup\SerializedFieldDataConverter $fieldDataConverter)
    {
        $this->fieldDataConverter = $fieldDataConverter;
    }

    public function execute()
    {
        $this->fieldDataConverter->convertSerializedDataToJson(
            'mageget_feed_entity',
            'entity_id',
            ['conditions_serialized']
        );
    }
}
