<?php
namespace Mageget\Checkout\Plugin\Checkout\Model;
 
use Magento\Quote\Model\QuoteRepository;
 
class ShippingInformationManagement
{
    protected $quoteRepository;
 
    public function __construct(QuoteRepository $quoteRepository) {
        $this->quoteRepository = $quoteRepository;
    }
 
    public function beforeSaveAddressInformation(
        \Magento\Checkout\Model\ShippingInformationManagement $subject,
        $cartId,
        \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
    ) {
       // echo "sadsads";exit;
        // print_r($addressInformation->getExtensionAttributes());
        // die();
        // $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        // $address = $objectManager->get('\Magento\Checkout\Api\Data\ShippingInformationInterface');
        // echo $address->getExtensionAttributes()->getComment();
        if(!$extAttributes = $addressInformation->getExtensionAttributes())
        {
            return;
        }
        var_dump($extAttributes);exit;
        $quote = $this->quoteRepository->getActive($cartId);
 
        $quote->setComment($extAttributes->getComment());
        $quote->setImage($extAttributes->getImage());
        $this->quoteRepository->save($quote);
    }
}