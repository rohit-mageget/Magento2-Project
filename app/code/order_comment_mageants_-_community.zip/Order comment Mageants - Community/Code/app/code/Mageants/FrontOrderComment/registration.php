<?php
/**
 * @category Mageants FrontOrderComment
 * @package Mageants_FrontOrderComment
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Mageants_FrontOrderComment', 
    __DIR__
);
