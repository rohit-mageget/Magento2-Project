var config = {
	"map": {
    "*": {
      "Magento_Sales/email/order_new.html":"Mageants_FrontOrderComment/email/order_new.html",
      "Magento_Checkout/js/action/place-order":"Mageants_FrontOrderComment/js/action/place-order",
      "Magento_Checkout/js/action/set-payment-information":"Mageants_FrontOrderComment/js/action/set-payment-information"
    }
  }
};
